<?php
//AMDG